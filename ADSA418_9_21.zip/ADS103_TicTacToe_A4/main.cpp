#include <iostream>
#include <string>
#include <windows.h>  
#include <vector>
#include <chrono>
#include "termcolor.h"

using namespace std;
using namespace termcolor;

// For different screens of the game 
enum Screen {

	MENU,
	HUMvsHUM = 1,
	COMPvsHUM = 2,
	EXIT = 3,
	NONE
};

// for Human vs Human
vector<int> playerTwoChoices;
vector<int> playerOneChoices;
bool printed = false, restartGrid;
bool onePicked, twoPicked, threePicked, fourPicked, fivePicked,
sixPicked, sevenPicked, eightPicked, ninePicked;
string place1, place2, place3, place4, place5,
place6, place7, place8, place9;

// DECLARATIONS OF FUNCTIONS 
int displayMenuScreen();
void displayGrid();
int playCompVSHum();
void playHumVSHum();
void displayGridChange(int playerOneChoice, int playerTwoChoice);
bool checkIfPlayer1Wins();
bool checkIfPlayer2Wins();
bool checkIfPlayer1GoingToWin();
bool checkIfPlayer2GoingToWin();
bool checkIfPlayersTie();

int main() {

	int choice = NONE; // set to a value no one can pick

	do {
		system("cls");
		choice = displayMenuScreen();

		if (choice == HUMvsHUM) {
			system("cls");
			playHumVSHum();
		}
		else if (choice == COMPvsHUM) {
			system("cls");
			playCompVSHum();
		}

	} while (choice != EXIT);

	// DO A QUIT SCENE
	cout << endl << "\tSee ya" << endl;
	system("pause");
	//quitScreen();
}

int displayMenuScreen() {

	int choice = Screen::NONE;
	string error = ""; // empty string

	do {

		cout << endl;
		cout << magenta << "\t\t--------- LETS PLAY " << yellow << "TIC TAC TOE" << magenta << " ---------\n\n " << termcolor::reset;
		cout << magenta << "\t\t\t--------- MENU ---------\n\n" << termcolor::reset;
		cout << yellow << "\t1." << white << "Play with a Friend!" << endl
			<< yellow << "\t2." << white << "Play with a Computer!" << endl
			<< yellow << "\t3." << white << "Quit Game" << endl;

		// if there is an error, show it 
		if (error != "") {
			cout << red << error << white;
			error = "";
		}
		cout << yellow << "\t>> ";

		cin >> choice;
		cout << endl;

		// if their choice isnt in the menu, then error 
		if (choice < 1 || choice > 3)
		{
			error = "\tHey! That isnt an option...try again\n";
			system("cls");
		}

	} while (error != "");

	return choice;
}

void displayGrid() {
	cout << white << "\t1" << yellow << " | " << white << "2" << yellow << " | " << white << "3" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t4" << yellow << " | " << white << "5" << yellow << " | " << white << "6" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t7" << yellow << " | " << white << "8" << yellow << " | " << white << "9" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
}

void displayGridChange(int playerOneChoice, int playerTwoChoice) {

	if (restartGrid) {

		place1 = "1";
		place2 = "2";
		place3 = "3";
		place4 = "4";
		place5 = "5";
		place6 = "6";
		place7 = "7";
		place8 = "8";
		place9 = "9";
	}

	restartGrid = false;

	if (playerOneChoice == 1) {

		onePicked = true;

		place1 = "X";
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}

	}
	else if (playerTwoChoice == 1) {

		onePicked = true;
		place1 = "O";

		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 2) {

		place2 = "X";
		twoPicked = true;
		if (!onePicked) {
			place1 = "1";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 2) {

		place2 = "O";
		twoPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 3) {

		place3 = "X";
		threePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 3) {

		place3 = "O";
		threePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 4) {

		place4 = "X";
		fourPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 4) {

		place4 = "O";
		fourPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 5) {

		place5 = "X";
		fivePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 5) {

		place5 = "O";
		fivePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 6) {

		place6 = "X";
		sixPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 6) {

		place6 = "O";
		sixPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 7) {

		place7 = "X";
		sevenPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 7) {

		place7 = "O";
		sevenPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!eightPicked) {
			place8 = "8";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 8) {

		place8 = "X";
		eightPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}
	else if (playerTwoChoice == 8) {

		place8 = "O";
		eightPicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!ninePicked) {
			place9 = "9";
		}
	}

	if (playerOneChoice == 9) {

		place9 = "X";
		ninePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
	}
	else if (playerTwoChoice == 9) {

		place9 = "O";
		ninePicked = true;

		if (!onePicked) {
			place1 = "1";
		}
		if (!twoPicked) {
			place2 = "2";
		}
		if (!threePicked) {
			place3 = "3";
		}
		if (!fourPicked) {
			place4 = "4";
		}
		if (!fivePicked) {
			place5 = "5";
		}
		if (!sixPicked) {
			place6 = "6";
		}
		if (!sevenPicked) {
			place7 = "7";
		}
		if (!eightPicked) {
			place8 = "8";
		}
	}



	cout << endl;
	cout << white << "\t" << place1 << yellow << " | " << white << place2 << yellow << " | " << white << place3 << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t" << place4 << yellow << " | " << white << place5 << yellow << " | " << white << place6 << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t" << place7 << yellow << " | " << white << place8 << yellow << " | " << white << place9 << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
}

int playCompVSHum()
{
	cout << magenta << "\t\t\t--------- COMPUTER VS PLAYER ---------\n\n" << termcolor::reset;
	cout << endl;
	cout << "\tYou are" << green << " X!" << white << " Input a number from the grid to claim that spot!" << endl << endl;
	displayGrid();
	int yuh;
	cin >> yuh;
	return 0;
}

void playHumVSHum()
{
	// Variables 
	int playerOne = 0, playerTwo = 0, seeWinner, playerInput;
	int grid[9] = { 1, 2, 3, 4, 5, 6, 7 ,8, 9 };
	int gridSize = sizeof(grid) / sizeof(grid[0]);
	bool player1Wins = false, player2Wins = false, playersTie = false, goingToBeARow = false;

	// make sure it hasnt been printed before
	if (!printed) {
		cout << magenta << "\t\t\t--------- PLAYER VS PLAYER ---------\n\n" << termcolor::reset;
		cout << "\tPlayer 1 is" << green << " X!" << white << " Player 2 is" << red << " O!" << white << endl << endl;
		cout << " \tInput a number from the grid to claim that spot!" << endl << endl;
		displayGrid();
		cout << endl << endl;
		printed = true;
	}

	do {
		// check if player 2 has won, if so make the bool
		if (checkIfPlayer2Wins() == true) {
			player2Wins = true;
		}

		// make sure player 2 hasnt won yet
		if (!player2Wins) {

			std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now(); // start timer 
			cout << white << "\tPlayer " << green << "ONE!" << white << " Go!" << endl;
			cout << green << "\t> ";
			// let player two make a choice
			cin >> playerOne;
			std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now(); // end timer
			auto timeTook1 = chrono::duration_cast<chrono::seconds>(end1 - begin1);

			// make sure the players choice is within the options
			if (playerOne >= 1 && playerOne <= 9) {
				// checks if the number has been picked before 
				while (count(playerOneChoices.begin(), playerOneChoices.end(), playerOne) || count(playerTwoChoices.begin(), playerTwoChoices.end(), playerOne)) {
					// if it has print out an error message and let them try again
					cout << "\t This spots taken! Pick another number!" << endl;
					cout << green << "\t> ";
					cin >> playerOne;
				}
				// adds there option to their list
				for (int i = 0; i < gridSize; i++) {

					if (playerOne == grid[i])
						playerOneChoices.push_back(playerOne);

				}
			}
		}
		else { // if player 2 wins

			// announce there has been a winner
			cout << "\tThere has been a winner! Press 0 to see the winner!" << endl;
			cout << "\t> ";
			cin >> seeWinner;

			// make sure they dont pick another number
			while (seeWinner != 0) {
				cout << "Thats not a 0!! Try Again" << endl;
				cout << "\t> ";
				cin >> seeWinner;
			}

			// if they pick the right option
			if (seeWinner == 0) {
				system("cls");
				displayGridChange(seeWinner, playerTwo); // display the grid
				cout << endl << red << "PLAYER TWO WINS!!" << endl << termcolor::reset; // announce winner
				cout << "Press 1 to go back to main menu!" << endl;
				cout << red << "> ";
				cin >> playerInput;

				// make sure they dont pick another number
				while (playerInput != 1) {

					cout << "\tYour number isnt an the option!! Try Again" << endl;
					cout << red << "> ";
					cin >> playerInput;
				}

				// if they pick the right number
				if (playerInput == 1) {

					// change the printed to false
					printed = false;
					// make sure the grid restarts if they play HUMvsHUM again
					restartGrid = true;
					// clear the lists
					playerOneChoices.clear();
					playerTwoChoices.clear();
					// go back to the main
					main();
				}
			}

		}

		//if (checkIfPlayersTie() == true) {
		//	if (playerOneChoices.size() + playerTwoChoices.size() == 8) {
		//		cout << "\tA Tie!! Press 0 to go back to main menu!" << endl;
		//		playersTie = true;
		//		cout << "\t> ";
		//		cin >> seeWinner;

		//		// make sure they dont pick wrong number
		//		while (seeWinner != 0) {
		//			cout << "\tThats not a 0!! Try Again" << endl;
		//			cout << "\t> ";
		//			cin >> seeWinner;
		//		}

		//		// if they chose correctly
		//		if (seeWinner == 0) {
		//			system("cls");
		//			displayGridChange(playerOne, playerTwo); // display grid
		//			// announce who won
		//			cout << endl << green << "TIE!!" << endl << termcolor::reset;
		//			// go back to the main menu
		//			cout << "Press 1 to go back to main menu!" << endl;
		//			cout << green << "> ";
		//			cin >> playerInput;

		//			// check if they chose wrong
		//			while (playerInput != 1) {

		//				cout << "\tYour number isnt an the option!! Try Again" << endl;
		//				cout << green << "> ";
		//				cin >> playerInput;
		//			}

		//			// if they chose right
		//			if (playerInput == 1) {

		//				printed = false; // make printed false
		//				restartGrid = true; // make sure grid doesnt stay set
		//				// reset the players lists
		//				playerOneChoices.clear();
		//				playerTwoChoices.clear();
		//				// go to main
		//				main();
		//			}
		//		}
		//	}
		//}


		// check if player 1 has won
		if (checkIfPlayer1Wins() == true) {

			player1Wins = true;
		}

		// if title has already printed 
		if (printed) {
			displayGridChange(playerOne, playerTwo); // print the new updated grid with the
			cout << white << "\tTry make three in a row!" << endl << termcolor::reset;
			if (checkIfPlayersTie() == true) {
				if (playerOneChoices.size() + playerTwoChoices.size() == 8) {
					cout << "\tA Tie!! Press 0 to go back to main menu!" << endl;
					playersTie = true;
					cout << "\t> ";
					cin >> seeWinner;

					// make sure they dont pick wrong number
					while (seeWinner != 0) {
						cout << "\tThats not a 0!! Try Again" << endl;
						cout << "\t> ";
						cin >> seeWinner;
					}

					// if they chose correctly
					if (seeWinner == 0) {
						system("cls");
						displayGridChange(playerOne, playerTwo); // display grid
						// announce who won
						cout << endl << green << "TIE!!" << endl << termcolor::reset;
						// go back to the main menu
						cout << "Press 1 to go back to main menu!" << endl;
						cout << green << "> ";
						cin >> playerInput;

						// check if they chose wrong
						while (playerInput != 1) {

							cout << "\tYour number isnt an the option!! Try Again" << endl;
							cout << green << "> ";
							cin >> playerInput;
						}

						// if they chose right
						if (playerInput == 1) {

							printed = false; // make printed false
							restartGrid = true; // make sure grid doesnt stay set
							// reset the players lists
							playerOneChoices.clear();
							playerTwoChoices.clear();
							// go to main
							main();
						}
					}
				}
			}
		}



		// if player 1 hasnt won
		if (!player1Wins) {
			std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now(); // start timer 
			cout << white << "\tPlayer " << red << "TWO!" << white << " Go!" << endl;
			cout << red << "\t> ";
			// let player two make a choice
			cin >> playerTwo;
			std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now(); // end timer

			// make sure there choice is in range
			if (playerTwo >= 1 && playerTwo <= 9) {
				while (count(playerTwoChoices.begin(), playerTwoChoices.end(), playerTwo) || count(playerOneChoices.begin(), playerOneChoices.end(), playerTwo)) {
					cout << "\t This spots taken! Pick another number!" << endl;
					cout << red << "\t> ";
					cin >> playerTwo;
				}

				// add their choice to their list 
				for (int i = 0; i < gridSize; i++) {

					if (playerTwo == grid[i])
						playerTwoChoices.push_back(playerTwo);

				}
			}
		}
		else { // if player 1 won

			// announce there has been a winner
			cout << "\tThere has been a winner! Press 0 to see the winner!" << endl;
			cout << "\t> ";
			cin >> seeWinner;

			// make sure they dont pick wrong number
			while (seeWinner != 0) {
				cout << "\tThats not a 0!! Try Again" << endl;
				cout << "\t> ";
				cin >> seeWinner;
			}

			// if they chose correctly
			if (seeWinner == 0) {
				system("cls");
				displayGridChange(playerOne, seeWinner); // display grid
				// announce who won
				cout << endl << green << "PLAYER ONE WINS!!" << endl << termcolor::reset;
				// go back to the main menu
				cout << "Press 1 to go back to main menu!" << endl;
				cout << green << "> ";
				cin >> playerInput;

				// check if they chose wrong
				while (playerInput != 1) {

					cout << "\tYour number isnt an the option!! Try Again" << endl;
					cout << green << "> ";
					cin >> playerInput;
				}

				// if they chose right
				if (playerInput == 1) {

					printed = false; // make printed false
					restartGrid = true; // make sure grid doesnt stay set
					// reset the players lists
					playerOneChoices.clear();
					playerTwoChoices.clear();
					// go to main
					main();
				}
			}
		}

		// if title has already printed 
		if (printed) {
			displayGridChange(playerOne, playerTwo); // print the new updated grid with the
			cout << white << "\tTry make three in a row!" << endl << termcolor::reset;
		if (checkIfPlayersTie() == true) {
			if (playerOneChoices.size() + playerTwoChoices.size() == 8) {
				cout << "\tA Tie!! Press 0 to go back to main menu!" << endl;
				playersTie = true;
				cout << "\t> ";
				cin >> seeWinner;

				// make sure they dont pick wrong number
				while (seeWinner != 0) {
					cout << "\tThats not a 0!! Try Again" << endl;
					cout << "\t> ";
					cin >> seeWinner;
				}

				// if they chose correctly
				if (seeWinner == 0) {
					system("cls");
					displayGridChange(playerOne, playerTwo); // display grid
					// announce who won
					cout << endl << green << "TIE!!" << endl << termcolor::reset;
					// go back to the main menu
					cout << "Press 1 to go back to main menu!" << endl;
					cout << green << "> ";
					cin >> playerInput;

					// check if they chose wrong
					while (playerInput != 1) {

						cout << "\tYour number isnt an the option!! Try Again" << endl;
						cout << green << "> ";
						cin >> playerInput;
					}

					// if they chose right
					if (playerInput == 1) {

						printed = false; // make printed false
						restartGrid = true; // make sure grid doesnt stay set
						// reset the players lists
						playerOneChoices.clear();
						playerTwoChoices.clear();
						// go to main
						main();
					}
				}
			}
		}
		}




		// make sure they dont pick a number not in the grid and repeat until they pick the right one
		while (playerOne < 1 || playerOne > 9) {
			cout << "\tYour number isnt in the grid!! Try Again" << endl;
			cout << red << "\t> ";
			cin >> playerOne;
		}

		// make sure they dont pick a number not in the grid and repeat until they pick the right one
		while (playerTwo < 1 || playerTwo > 9) {
			cout << "\tYour number isnt in the grid!! Try Again" << endl;
			cout << red << "\t> ";
			cin >> playerTwo;
		}




		cout << endl;

		// keep calling the function till someone wins
		playHumVSHum();

	} while (player1Wins == false || player2Wins == false || playersTie == false);

	return;
}

bool checkIfPlayer1GoingToWin() {
	// ----- PLAYER 1 -----
	// diagonals
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 9)) {

		return false;
	}

	if (count(playerOneChoices.begin(), playerOneChoices.end(), 3) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 7)) {

		return false;
	}

	// down
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 4)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 7) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 4)) {

		return false;
	}

	if (count(playerOneChoices.begin(), playerOneChoices.end(), 2) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 8) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;
	}

	if (count(playerOneChoices.begin(), playerOneChoices.end(), 3) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 6)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 9) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 6)) {

		return false;
	}

	//across
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 2)) {

		return false;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 2) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 3)) {

		return false;
	}

	if (count(playerOneChoices.begin(), playerOneChoices.end(), 4) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 6) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5)) {

		return false;
	}

	if (count(playerOneChoices.begin(), playerOneChoices.end(), 7) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 8)) {

		return false;
	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 9) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 8)) {

		return false;
	}

	return true;
}

bool checkIfPlayer2GoingToWin() {

	// ----- PLAYER 2 -----
// diagonals
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 9)) {

		return false;
	}

	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 3) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 7)) {

		return false;
	}

	// down
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 4)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 7) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 4)) {

		return false;
	}

	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 2) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 8) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;
	}

	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 3) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 6)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 9) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 6)) {

		return false;
	}

	//across
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 2)) {

		return false;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 2) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 3)) {

		return false;
	}

	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 4) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 6) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5)) {

		return false;
	}

	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 7) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 8)) {

		return false;
	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 9) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 8)) {

		return false;
	}

	return true;
}

bool checkIfPlayer1Wins() {


	// ----- PLAYER 1 -----
	// diagonals
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 9)) {

		return true;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 3) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 7)) {

		return true;

	}

	// down
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 4) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 7)) {

		return true;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 2) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 8)) {

		return true;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 3) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 6) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 9)) {

		return true;

	}

	//across
	if (count(playerOneChoices.begin(), playerOneChoices.end(), 1) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 2) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 3)) {

		return true;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 4) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 5) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 6)) {

		return true;

	}
	else if (count(playerOneChoices.begin(), playerOneChoices.end(), 7) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 8) &&
		count(playerOneChoices.begin(), playerOneChoices.end(), 9)) {

		return true;

	}
}

bool checkIfPlayer2Wins() {

	// ----- PLAYER 2 -----
	// diagonal
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 9)) {

		return true;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 3) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 7)) {

		return true;

	}

	// down
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 4) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 7)) {

		return true;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 2) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 8)) {

		return true;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 3) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 6) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 9)) {

		return true;

	}

	// across
	if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 1) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 2) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 3)) {

		return true;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 4) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 5) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 6)) {

		return true;

	}
	else if (count(playerTwoChoices.begin(), playerTwoChoices.end(), 7) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 8) &&
		count(playerTwoChoices.begin(), playerTwoChoices.end(), 9)) {

		return true;

	}
}

bool checkIfPlayersTie() {

	if (place1 == "X" || place1 == "O") {
		if (place2 == "X" || place2 == "O") {
			if (place3 == "X" || place3 == "O") {
				if (place4 == "X" || place4 == "O") {
					if (place5 == "X" || place5 == "O") {
						if (place6 == "X" || place6 == "O") {
							if (place7 == "X" || place7 == "O") {
								if (place8 == "X" || place8 == "O") {
									if (place9 == "X" || place9 == "O") {
										return true;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	return false;
}
